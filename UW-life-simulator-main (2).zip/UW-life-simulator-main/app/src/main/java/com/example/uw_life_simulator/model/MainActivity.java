package com.example.uw_life_simulator.model;

import android.content.Intent;
import android.os.Bundle;

import com.example.uw_life_simulator.R;
import com.example.uw_life_simulator.Service.DbCleanService;
import com.example.uw_life_simulator.Service.DbInitializeService;
import com.example.uw_life_simulator.activities.CourseSelectionActivity;
import com.example.uw_life_simulator.activities.DrawSpellCardActivity;
import com.example.uw_life_simulator.activities.EventActivity;
import com.example.uw_life_simulator.activities.AttributeActivities;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.uw_life_simulator.activities.HelpActivity;
import com.example.uw_life_simulator.activities.SwipeSpellCardActivity;
import com.example.uw_life_simulator.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.button4);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void createTalent(View view) {
        DbInitializeService dbInitializeService = new DbInitializeService(this);
        dbInitializeService.initializeAll();
        Intent intent = new Intent(MainActivity.this, AttributeActivities.class);
        startActivity(intent);
    }
    public void createEvent(View view) {
        Intent intent = new Intent(MainActivity.this, EventActivity.class);
        startActivity(intent);
    }

    public void selectCourse(View view) {
        Intent intent = new Intent(MainActivity.this, CourseSelectionActivity.class);
        startActivity(intent);
    }

    public void goHelpPage(View view) {
        Intent intent = new Intent(MainActivity.this, HelpActivity.class);
        startActivity(intent);
    }

    public void quitApp(View view) {
        System.exit(0);
//        DbCleanService dbCleanService = new DbCleanService(getApplicationContext());
//        dbCleanService.cleanDb();

        //Intent intent = new Intent(MainActivity.this, DrawSpellCardActivity.class);
        //startActivity(intent);
    }

    public void SwipeCard(View view) {
        Intent intent = new Intent(MainActivity.this, SwipeSpellCardActivity.class);
        startActivity(intent);
    }
}