package com.example.uw_life_simulator.model;

public interface Subject {
    void accept(Visitor visitor);
}
